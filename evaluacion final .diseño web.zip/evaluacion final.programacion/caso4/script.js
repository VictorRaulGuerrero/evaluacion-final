function currentTime(){ //muestra la hora actual
    let date = new Date();//crea un objeto que contiene la hora y la fecha ctual
    let hh = date.getHours();// se obtienen las horas
    let mn = date.getMinutes();//se obtienen los minutos
    let ss = date.getSeconds();// se obtienen los sgundos

    if (hh<10) hh="0"+hh;//si la hora es menor de 10 se agrega un cero al inicioo de cada hora
    //hh = hh <10 ? "0"+ hh; condicional terniario
    if (mn<10) mn="0"+mn;//Si los minutos son menores a 10 se agregaa un cero al inicio
    if (ss<10) ss="0"+ss;//si los segundos son menores a 10 se agrega un cero al inicio

    let time = hh + ":" + mn + ":" + ss;// Crear el string de la hora en formato hh:mm:ss
    //let time=`${hh}:${mn}:${ss}`template string

    let watch = document.querySelector('#watch');// Selecciona el elemento con el id "watch"
    //let watch = document.getElemntById ('watch');

    watch.innerHTML = time;// Pone la hora actual en el contenido HTML del elemento

    //console.log(time);
}
setInterval(currentTime,1000);//Llama a la función currentTime cada 1 segundo (1000 ms)
