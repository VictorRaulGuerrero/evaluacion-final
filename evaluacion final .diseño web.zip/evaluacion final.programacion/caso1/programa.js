var n; // se usa var para declarar variables
document.getElementById("calculate").addEventListener("click", function () {
    const start = parseInt(document.getElementById("start").value); // const porque no cambia
    const end = parseInt(document.getElementById("end").value);
  
    if (isNaN(start) || isNaN(end)) {
      alert("Por favor, introduce números válidos.");
      return;
    }
  
    var evenSum = 0; // var porque tiene alcance global en la función
    var oddSum = 0;
  
    for (let i = start; i <= end; i++) { // let porque cambia en cada iteración
      if (i % 2 === 0) {
        evenSum += i;
      } else {
        oddSum += i;
      }
    }
  
    const result = { evenSum, oddSum }; // const porque no cambia la referencia del objeto
  
    // Mostrar resultados en la página
    document.getElementById("evenSum").textContent = "Suma de pares: " + result.evenSum;
    document.getElementById("oddSum").textContent = "Suma de impares: " + result.oddSum;
  });
  