// Datos de los departamentos
const properties = [
    {
      image: "img/imagen1.jpg",
      builder: "TALE CONSTRUCTORA SAC",
      price: "$78,850",
      area: "57.40 m2",
    },
    {
      image: "img/imagen2.jpeg",
      builder: "TALE CONSTRUCTORA SAC",
      price: "$85,000",
      area: "62.50 m2",
    },
    {
      image: "img/imagen3.jpeg",
      builder: "TALE CONSTRUCTORA SAC",
      price: "$92,500",
      area: "65.80 m2",
    },
    {
      image: "img/imagen4.jpeg",
      builder: "TALE CONSTRUCTORA SAC",
      price: "$75,000",
      area: "58.90 m2",
    },
    {
      image: "img/imagen5.jpeg",
      builder: "TALE CONSTRUCTORA SAC",
      price: "$88,000",
      area: "60.30 m2",
    },
    {
      image: "img/imagen6.jpeg",
      builder: "TALE CONSTRUCTORA SAC",
      price: "$90,000",
      area: "64.00 m2",
    },
  ];
  
  let currentIndex = 0;
  
  // Elementos del DOM
  const propertyImage = document.getElementById("propertyImage");
  const builder = document.getElementById("builder");
  const price = document.getElementById("price");
  const area = document.getElementById("area");
  const message = document.getElementById("message");
  const prevButton = document.getElementById("prevButton");
  const nextButton = document.getElementById("nextButton");
  
  // Función para actualizar la información del departamento
  function updateProperty() {
    const property = properties[currentIndex];
    propertyImage.src = property.image;
    builder.textContent = property.builder;
    price.textContent = property.price;
    area.textContent = property.area;
  
    // Actualizar el estado de los botones y mensajes
    prevButton.disabled = currentIndex === 0;
    nextButton.disabled = currentIndex === properties.length - 1;
  
    message.textContent =
      currentIndex === 0
        ? "Estás en el inicio de las propiedades."
        : currentIndex === properties.length - 1
        ? "Estás en el final de las propiedades."
        : "";
  }
  
  // Event listeners para los botones
  prevButton.addEventListener("click", () => {
    if (currentIndex > 0) {
      currentIndex--;
      updateProperty();
    }
  });
  
  nextButton.addEventListener("click", () => {
    if (currentIndex < properties.length - 1) {
      currentIndex++;
      updateProperty();
    }
  });
  
  // Inicializar la galería
  updateProperty();
  